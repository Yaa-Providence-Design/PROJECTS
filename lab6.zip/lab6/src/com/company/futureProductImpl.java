package com.company;

public class futureProductImpl extends itr.futureProduct {
    @Override
    public void exchange(String ex) {

    }

    @Override
    public void concontractCode(String con) {

    }

    @Override
    public void month(int mth) {

    }

    @Override
    public void year(int yr) {

    }
}
